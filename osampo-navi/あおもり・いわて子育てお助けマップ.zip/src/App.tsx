import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import {
  Search,
  MapPin,
  Phone,
  Clock,
  Calendar,
  Baby,
  Smile,
  X,
  Compass,
  Filter,
  Check,
  Heart,
  ExternalLink,
  ChevronRight,
  Info,
  HelpCircle,
  Cloud,
  RefreshCw,
  LogIn,
  LogOut,
  Database
} from 'lucide-react';
import { locations, Location, Review } from './data';
import {
  initAuth,
  googleSignIn,
  googleSignOut,
  saveReviewsToDrive,
  loadReviewsFromDrive
} from './firebase';
import { User } from 'firebase/auth';

const categoryColors: Record<string, { bg: string; text: string; label: string; emoji: string }> = {
  playground: { bg: 'bg-emerald-50 text-emerald-800 border-2 border-emerald-200', text: 'text-emerald-800', label: '遊び場・公園', emoji: '🛝' },
  nursing: { bg: 'bg-sky-50 text-sky-800 border-2 border-sky-100', text: 'text-sky-800', label: '授乳・ケア', emoji: '🍼' },
  shopping: { bg: 'bg-orange-50 text-orange-850 border-2 border-orange-200', text: 'text-orange-800', label: '買い物', emoji: '🛒' },
  restaurant: { bg: 'bg-amber-50 text-amber-900 border-2 border-amber-200', text: 'text-amber-800', label: '飲食店', emoji: '🍴' },
  roadside_station: { bg: 'bg-purple-50 text-purple-800 border-2 border-purple-200', text: 'text-purple-800', label: '道の駅', emoji: '🚗' },
  museum: { bg: 'bg-indigo-50 text-indigo-850 border-2 border-indigo-200', text: 'text-indigo-800', label: 'ミュージアム', emoji: '🎨' },
  public: { bg: 'bg-teal-50 text-teal-850 border-2 border-teal-200', text: 'text-teal-800', label: '公共窓口', emoji: '🏢' },
  convenience: { bg: 'bg-rose-50 text-rose-800 border-2 border-rose-200', text: 'text-rose-800', label: 'コンビニ', emoji: '🏪' },
  hotel: { bg: 'bg-pink-50 text-pink-850 border-2 border-pink-200', text: 'text-pink-850', label: '温泉・宿', emoji: '♨️' },
  transport: { bg: 'bg-cyan-50 text-cyan-850 border-2 border-cyan-200', text: 'text-cyan-800', label: '交通', emoji: '🚃' },
  landmark: { bg: 'bg-slate-50 text-slate-800 border-2 border-slate-200', text: 'text-slate-700', label: 'その他', emoji: '📍' }
};

export default function App() {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerGroupRef = useRef<L.LayerGroup | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const watchIdRef = useRef<number | null>(null);
  const userCircleRef = useRef<L.Circle | null>(null);

  // States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSpot, setSelectedSpot] = useState<Location | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [filter5km, setFilter5km] = useState(false);
  const [mobileTab, setMobileTab] = useState<'map' | 'list'>('map');
  const [showLegend, setShowLegend] = useState(false);

  // Google Drive Integration States
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [isDriveConnected, setIsDriveConnected] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string>('');

  // Initialize Firebase Auth & Auto-link Google Drive state on component mount
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setGoogleUser(user);
        setIsDriveConnected(!!token);
      },
      () => {
        setGoogleUser(null);
        setIsDriveConnected(false);
      }
    );
    return () => {
      unsubscribe();
    };
  }, []);

  // Sign in with Google Drive scopes
  const handleGoogleConnect = async () => {
    setIsSyncing(true);
    setSyncMessage('Googleアカウントに接続中...');
    try {
      const result = await googleSignIn();
      if (result) {
        setGoogleUser(result.user);
        setIsDriveConnected(true);
        setSyncMessage('接続完了しました！');
        
        // Auto-load backup if available on first connect to merge/restore
        setSyncMessage('最新のバックアップを取得中...');
        const driveData = await loadReviewsFromDrive();
        if (driveData) {
          const confirmMerge = window.confirm(
            'Google Driveからバックアップデータが見つかりました。\n現在のブラウザのクチコミと統合（マージ）して復元しますか？'
          );
          if (confirmMerge) {
            setSpotReviews((prev) => {
              const merged = { ...prev };
              Object.keys(driveData).forEach((spotName) => {
                const prevReviews = prev[spotName] || [];
                const incomingReviews = driveData[spotName] || [];
                const filteredIncoming = incomingReviews.filter(
                  (incoming: Review) =>
                    !prevReviews.some(
                      (p) => p.comment === incoming.comment && p.rating === incoming.rating
                    )
                );
                if (filteredIncoming.length > 0) {
                  merged[spotName] = [...prevReviews, ...filteredIncoming];
                }
              });
              return merged;
            });
            setSyncMessage('データを復元・統合しました！🍉');
          } else {
            setSyncMessage('Google Driveに接続しました。');
          }
        } else {
          setSyncMessage('新規バックアップが作成可能です。');
        }
      }
    } catch (err: any) {
      console.error(err);
      setSyncMessage('接続、またはデータ読み込みに失敗しました。');
    } finally {
      setIsSyncing(false);
    }
  };

  // backup actual Reviews to Google Drive
  const handleBackupToDrive = async () => {
    if (!isDriveConnected) return;
    setIsSyncing(true);
    setSyncMessage('Google Driveにバックアップ中...');
    try {
      await saveReviewsToDrive(spotReviews);
      setSyncMessage('クラウドに複製バックアップ完了！✨');
      alert('Google Driveに「papamama_spots_reviews_backup.json」としてレビューデータを安全にバックアップしました！');
    } catch (err) {
      console.error(err);
      setSyncMessage('バックアップに失敗しました。');
      alert('バックアップの作成に失敗しました。再接続をお試しください。');
    } finally {
      setIsSyncing(false);
    }
  };

  // Manual Restore
  const handleRestoreFromDrive = async () => {
    if (!isDriveConnected) return;
    setIsSyncing(true);
    setSyncMessage('バックアップデータを読み込み中...');
    try {
      const driveData = await loadReviewsFromDrive();
      if (driveData) {
        const confirmRestore = window.confirm(
          'Google Driveのバックアップでクチコミを復元します。\n\n[OK]：上書きして完全に復元\n[キャンセル]：現在のデータと統合（マージ）'
        );
        if (confirmRestore) {
          setSpotReviews(driveData);
          setSyncMessage('バックアップから完全に上書き復元しました！');
          alert('Google Driveのデータからクチコミを上書き復元完了しました！');
        } else {
          setSpotReviews((prev) => {
            const merged = { ...prev };
            Object.keys(driveData).forEach((spotName) => {
              const prevReviews = prev[spotName] || [];
              const incomingReviews = driveData[spotName] || [];
              const filteredIncoming = incomingReviews.filter(
                (incoming: Review) =>
                  !prevReviews.some(
                    (p) => p.comment === incoming.comment && p.rating === incoming.rating
                  )
              );
              if (filteredIncoming.length > 0) {
                merged[spotName] = [...prevReviews, ...filteredIncoming];
              }
            });
            return merged;
          });
          setSyncMessage('現在のデータと統合（マージ）して復元しました！');
          alert('Google Driveから現在のクチコミ一覧とマージして復元しました。');
        }
      } else {
        setSyncMessage('バックアップが見つかりません。');
        alert('Google Drive上にまだバックアップがありません。「保存」を押してバックアップを作成してください。');
      }
    } catch (err) {
      console.error(err);
      setSyncMessage('読み込み失敗。再ログインをお試しください。');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleGoogleDisconnect = async () => {
    try {
      await googleSignOut();
      setGoogleUser(null);
      setIsDriveConnected(false);
      setSyncMessage('接続完了をオフにしました。');
    } catch (err) {
      console.error(err);
    }
  };

  // States & Dynamic Reviews persistence
  const [spotReviews, setSpotReviews] = useState<Record<string, Review[]>>(() => {
    const saved = localStorage.getItem('papamama_reviews_v3');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return {
      "こどもはっち (はっち4階)": [
        { rating: 5, comment: "完全室内で安心！おむつ台や授乳室がとても綺麗です。", author: "はっちママ", date: "2026-06-21" }
      ],
      "道の駅 いわて北三陸": [
        { rating: 4, comment: "新しい道の駅で、幼児向けの遊び場スペースや綺麗な授乳室があります。", author: "北のパパ", date: "2026-06-20" }
      ],
      "十和田市現代美術館 (キッズエリア)": [
        { rating: 4, comment: "外のお化けのモニュメントに子どもたちが大喜びでした！", author: "十和田ママ", date: "2026-06-19" }
      ],
      "いわて子どもの森（一戸町）": [
        { rating: 5, comment: "超大型の室内遊具があって、雨の日でも1日中楽しめます！", author: "一戸ママ", date: "2026-06-18" }
      ]
    };
  });

  const [ratingInput, setRatingInput] = useState<number>(5);
  const [commentInput, setCommentInput] = useState<string>('');
  const [authorInput, setAuthorInput] = useState<string>('');
  
  // Custom Amenity Filters
  const [filterNursing, setFilterNursing] = useState(false);
  const [filterDiaper, setFilterDiaper] = useState(false);
  const [filterHotWater, setFilterHotWater] = useState(false);
  const [filterStroller, setFilterStroller] = useState(false);
  const [filterSeating, setFilterSeating] = useState(false);

  // Stats
  const [filteredLocations, setFilteredLocations] = useState<Location[]>(locations);

  // Category template configuration matching Leaflet icons
  const iconTemplates: Record<string, string> = {
    playground: '🛝',
    nursing: '🍼',
    shopping: '🛒',
    restaurant: '🍴',
    roadside_station: '🚗',
    museum: '🎨',
    public: '🏢',
    convenience: '🏪',
    hotel: '♨️',
    transport: '🚃',
    landmark: '📍'
  };

  // Build unified icon generator in Vibrant Palette Theme style
  const createCustomIcon = (emoji: string, isActive: boolean = false) => {
    return L.divIcon({
      html: `
        <div class="relative flex items-center justify-center pointer-events-none">
          <div class="w-11 h-11 ${
            isActive 
              ? 'bg-[#f97316] text-white scale-125 border-4 border-white shadow-2xl animate-bounce' 
              : 'bg-white text-slate-800 border-2 border-orange-200 hover:scale-110 shadow-md'
          } rounded-full flex items-center justify-center transition-all duration-300">
            <span style="font-size: 21px; font-family: sans-serif;">${emoji}</span>
          </div>
          <div class="absolute -bottom-1.5 w-3.5 h-3.5 ${isActive ? 'bg-[#f97316]' : 'bg-orange-400'} rotate-45 border-r border-b border-orange-100 shadow-sm"></div>
        </div>
      `,
      className: 'custom-baby-marker',
      iconSize: [44, 44],
      iconAnchor: [22, 44],
      popupAnchor: [0, -44]
    });
  };

  // 1. Initalize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    // Use Hachinohe as the initial map camera point
    const map = L.map(mapContainerRef.current, {
      zoomControl: false // Custom styled zoom control later
    }).setView([40.5126, 141.4901], 10);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // Custom Zoom controls position
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    const markerGroup = L.layerGroup().addTo(map);

    mapRef.current = map;
    markerGroupRef.current = markerGroup;

    // Start geolocation service
    tryGeolocate();

    return () => {
      map.remove();
      mapRef.current = null;
      userMarkerRef.current = null;
      userCircleRef.current = null;
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  // Save reviews list automatically when it updates
  useEffect(() => {
    localStorage.setItem('papamama_reviews_v3', JSON.stringify(spotReviews));
  }, [spotReviews]);

  // Handle drawing & updating a 5km radius circle around the user's location
  useEffect(() => {
    if (!mapRef.current || !userLocation) return;

    if (userCircleRef.current) {
      userCircleRef.current.setLatLng([userLocation.lat, userLocation.lng]);
    } else {
      userCircleRef.current = L.circle([userLocation.lat, userLocation.lng], {
        radius: 5000, // 5km
        color: '#f97316', // tailwind orange-500
        weight: 3,
        opacity: 0.85,
        dashArray: '8, 8',
        fillColor: '#f97316',
        fillOpacity: 0.12
      }).addTo(mapRef.current);
    }

    // Auto-fit bounds on initial load of user locations
    try {
      const bounds = userCircleRef.current.getBounds();
      mapRef.current.fitBounds(bounds, { padding: [30, 30] });
    } catch (e) {
      console.warn("Failed to update map bounds:", e);
    }

    return () => {
      if (userCircleRef.current && mapRef.current) {
        mapRef.current.removeLayer(userCircleRef.current);
        userCircleRef.current = null;
      }
    };
  }, [userLocation]);

  // 2. Perform Geolocation to calculate distance (Continuous Position Monitoring)
  const tryGeolocate = () => {
    if (!navigator.geolocation) return;

    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
    }

    setIsTracking(true);
    const id = navigator.geolocation.watchPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation({ lat: latitude, lng: longitude });
        setIsTracking(false);

        // Update GPS marker on the map in real-time
        if (mapRef.current) {
          if (userMarkerRef.current) {
            userMarkerRef.current.setLatLng([latitude, longitude]);
          } else {
            userMarkerRef.current = L.marker([latitude, longitude], {
              icon: L.divIcon({
                html: `
                  <div class="relative flex items-center justify-center pointer-events-none">
                    <div class="w-8 h-8 bg-sky-450 bg-sky-400 border-4 border-white rounded-full flex items-center justify-center text-sm shadow-xl">🏃</div>
                    <div class="absolute w-12 h-12 bg-sky-300 rounded-full opacity-35 animate-ping"></div>
                  </div>
                `,
                className: 'user-pin',
                iconSize: [36, 36],
                iconAnchor: [18, 18]
              })
            }).addTo(mapRef.current);
          }
        }
      },
      (error) => {
        console.warn('Geolocation failed:', error);
        setIsTracking(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
    watchIdRef.current = id;
  };

  const getDistanceInKm = (spotLat: number, spotLng: number) => {
    if (!userLocation) return Infinity;
    const R = 6371; // Earth's radius (km)
    const dLat = ((spotLat - userLocation.lat) * Math.PI) / 180;
    const dLon = ((spotLng - userLocation.lng) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((userLocation.lat * Math.PI) / 180) *
        Math.cos((spotLat * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Haversine formula to compute beautiful distance string
  const getDistanceString = (spotLat: number, spotLng: number) => {
    if (!userLocation) return null;
    const dist = getDistanceInKm(spotLat, spotLng);
    if (dist === Infinity) return null;
    return dist < 1 ? `${Math.round(dist * 1000)}m` : `${dist.toFixed(1)}km`;
  };

  // 3. Process Filters Whenever Dependency State Changes
  useEffect(() => {
    const query = searchQuery.toLowerCase().trim();

    const result = locations.filter((spot) => {
      // 1. Category filter
      if (selectedCategory !== 'all' && spot.category !== selectedCategory) {
        return false;
      }

      // 2. Custom Switches
      if (filterNursing && !spot.nursingSpace) return false;
      if (filterDiaper && !spot.diaperChange) return false;
      if (filterHotWater && !spot.hotWater) return false;
      if (filterStroller && !spot.strollerFriendly) return false;
      if (filterSeating && !spot.kidSeating) return false;

      // 3. Keywords search
      if (query) {
        const matchesName = spot.name.toLowerCase().includes(query);
        const matchesAmenities = spot.amenities.toLowerCase().includes(query);
        const matchesCity = spot.city?.toLowerCase().includes(query) || false;
        const matchesAddress = spot.address?.toLowerCase().includes(query) || false;
        
        return matchesName || matchesAmenities || matchesCity || matchesAddress;
      }

      return true;
    });

    // Handle 5km radius filtering & sorting by nearest
    let finalResult = [...result];
    if (userLocation) {
      if (filter5km) {
        finalResult = finalResult.filter((spot) => {
          const dist = getDistanceInKm(spot.lat, spot.lng);
          return dist <= 5.0; // within 5km
        });
      }

      // Dynamic sorting - nearest locations first!
      finalResult.sort((a, b) => {
        const distA = getDistanceInKm(a.lat, a.lng);
        const distB = getDistanceInKm(b.lat, b.lng);
        return distA - distB;
      });
    }

    setFilteredLocations(finalResult);

    // Update coordinates and markers on the Map
    if (mapRef.current && markerGroupRef.current) {
      markerGroupRef.current.clearLayers();

      finalResult.forEach((spot) => {
        // Automatically overwrite to standard slide (🛝) if park keywords exist inside the name
        let emoji = iconTemplates[spot.category] || '📍';
        if (
          spot.name.includes("公園") ||
          spot.name.includes("広場") ||
          spot.name.includes("こども館") ||
          spot.name.includes("遊び場")
        ) {
          emoji = '🛝';
        }

        const isSelected = selectedSpot?.name === spot.name;
        const marker = L.marker([spot.lat, spot.lng], {
          icon: createCustomIcon(emoji, isSelected)
        });

        marker.on('click', () => {
          setSelectedSpot(spot);
          mapRef.current?.setView([spot.lat - 0.005, spot.lng], 14, { animate: true });
        });

        markerGroupRef.current?.addLayer(marker);
      });
    }
  }, [
    searchQuery,
    selectedCategory,
    filterNursing,
    filterDiaper,
    filterHotWater,
    filterStroller,
    filterSeating,
    selectedSpot,
    userLocation,
    filter5km
  ]);

  // Center a chosen spot
  const handleSpotSelect = (spot: Location) => {
    setSelectedSpot(spot);
    setMobileTab('map');
    if (mapRef.current) {
      mapRef.current.setView([spot.lat - 0.005, spot.lng], 14, { animate: true });
    }
  };

  // 4. Handle adding a custom dynamic review
  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSpot) return;
    if (!commentInput.trim()) return;

    const nickname = authorInput.trim() || 'パパママ会員';
    const newReview: Review = {
      rating: ratingInput,
      comment: commentInput.trim(),
      author: nickname,
      date: new Date().toISOString().split('T')[0]
    };

    const existingReviews = spotReviews[selectedSpot.name] || [];
    const updatedReviews = [newReview, ...existingReviews];

    setSpotReviews(prev => ({
      ...prev,
      [selectedSpot.name]: updatedReviews
    }));

    // Reset inputs
    setCommentInput('');
    setAuthorInput('');
    setRatingInput(5);
  };

  // 5. Handle enter key press on search input (簡易検索機能 matching searchAddress)
  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const query = searchQuery.trim().toLowerCase();
      if (!query) return;
      const found = filteredLocations.find(spot => 
        spot.name.toLowerCase().includes(query) || 
        spot.address?.toLowerCase().includes(query) ||
        spot.amenities?.toLowerCase().includes(query)
      );
      if (found) {
        handleSpotSelect(found);
      }
    }
  };

  // Render a nice set of quick category buttons
  const categoryTabs = [
    { id: 'all', emoji: '🌟', label: 'すべて' },
    { id: 'playground', emoji: '🛝', label: '遊び場・公園' },
    { id: 'nursing', emoji: '🍼', label: '授乳・ケア' },
    { id: 'shopping', emoji: '🛒', label: '買い物・買う' },
    { id: 'restaurant', emoji: '🍴', label: '飲食店' },
    { id: 'roadside_station', emoji: '🚗', label: '道の駅' },
    { id: 'museum', emoji: '🎨', label: 'ミュージアム' },
    { id: 'public', emoji: '🏢', label: '公共窓口' },
    { id: 'convenience', emoji: '🏪', label: 'コンビニ' },
    { id: 'hotel', emoji: '♨️', label: '温泉・宿' },
    { id: 'transport', emoji: '🚃', label: '駅・交通' },
    { id: 'landmark', emoji: '📍', label: 'その他' }
  ];

  return (
    <div id="app-container" className="flex flex-col h-screen overflow-hidden bg-amber-50">
      
      {/* HEADER BAR */}
      <header className="bg-white border-b-4 border-orange-500 py-4 px-6 shadow-sm shrink-0 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center text-white text-2xl font-black shadow-lg shadow-orange-100 animate-bounce shrink-0">
            P
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span>PAPA & MAMA</span>
              <span className="text-orange-500 italic">MAP</span>
            </h1>
            <p className="text-xs text-slate-500 font-bold hidden md:block">
              青森県・岩手県内のベビーカー対応店、授乳室、おむつ替え、公園をまとめて検索
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 justify-end w-full sm:w-auto">
          {/* GOOGLE DRIVE SYNC PANEL */}
          <div className="flex items-center gap-3 bg-orange-50/50 border-2 border-orange-100/60 px-4 py-2 rounded-2xl shadow-sm max-w-full">
            <div className="flex flex-col text-right">
              {googleUser ? (
                <>
                  <span className="text-[10px] text-slate-700 font-extrabold flex items-center gap-1.5 justify-end">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block animate-pulse font-sans"></span>
                    Drive 連携中 ({googleUser.displayName || 'ユーザー'})
                  </span>
                  {syncMessage ? (
                    <span className="text-[9px] text-orange-600 font-bold max-w-[200px] truncate">{syncMessage}</span>
                  ) : (
                    <span className="text-[9px] text-slate-400">クチコミを安全にクラウド保存中</span>
                  )}
                </>
              ) : (
                <>
                  <span className="text-[10px] text-slate-600 font-black">Google Drive 連携</span>
                  <span className="text-[9px] text-slate-400">クチコミをクラウドに残せます</span>
                </>
              )}
            </div>

            {googleUser ? (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleBackupToDrive}
                  disabled={isSyncing}
                  title="Google Driveに現在のクチコミをバックアップ"
                  className="bg-orange-500 text-white hover:bg-orange-600 px-3 py-1.5 rounded-xl text-xs font-black cursor-pointer flex items-center gap-1 hover:scale-105 active:scale-95 transition shadow-md shadow-orange-100"
                >
                  <Cloud className="w-3.5 h-3.5" />
                  保存
                </button>
                <button
                  onClick={handleRestoreFromDrive}
                  disabled={isSyncing}
                  title="Google Driveからバックアップを読み込み（復元）"
                  className="bg-sky-500 text-white hover:bg-sky-600 px-3 py-1.5 rounded-xl text-xs font-black cursor-pointer flex items-center gap-1 hover:scale-105 active:scale-95 transition shadow-md shadow-sky-100"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  復元
                </button>
                <button
                  onClick={handleGoogleDisconnect}
                  title="Google Drive連携を解除"
                  className="bg-slate-100 text-slate-500 hover:bg-slate-200 p-2 rounded-xl text-xs font-black cursor-pointer flex items-center justify-center hover:scale-105 transition"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={handleGoogleConnect}
                disabled={isSyncing}
                className="bg-white border-2 border-slate-200 text-slate-700 hover:bg-slate-50 px-3 py-1.5 rounded-xl text-xs font-black shadow-sm flex items-center gap-1.5 cursor-pointer hover:border-orange-200 hover:scale-105 transition"
              >
                <Database className="w-4 h-4 text-orange-500" />
                <span>Driveに保存</span>
              </button>
            )}
          </div>

          {/* GPS tracking trigger */}
          <button
            onClick={tryGeolocate}
            disabled={isTracking}
            title="現在地を取得して距離を計算します"
            className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-black shadow-lg hover:scale-105 transition-all duration-300 cursor-pointer shrink-0 ${
              userLocation 
                ? 'bg-sky-400 text-white shadow-sky-100 hover:bg-sky-500'
                : 'bg-orange-500 text-white shadow-orange-100 hover:bg-orange-600'
            }`}
          >
            <Compass className={`w-4 h-4 ${isTracking ? 'animate-spin' : ''}`} />
            <span>{userLocation ? 'GPS連携中 🏃‍♂️' : '現在地から探す'}</span>
          </button>
        </div>
      </header>

      {/* MOBILE SWITCHER SEGMENTS */}
      <div className="flex md:hidden bg-white border-b-2 border-slate-100 p-2 shrink-0 select-none z-20 flex-col gap-2">
        <div className="grid grid-cols-2 gap-1 w-full bg-slate-100 p-1 rounded-2xl">
          <button
            onClick={() => setMobileTab('map')}
            className={`py-2.5 text-xs font-black rounded-xl transition-all flex items-center justify-center gap-1.5 relative cursor-pointer ${
              mobileTab === 'map'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>🗺️</span>
            <span>マップ表示</span>
          </button>
          <button
            onClick={() => setMobileTab('list')}
            className={`py-2.5 text-xs font-black rounded-xl transition-all flex items-center justify-center gap-1.5 relative cursor-pointer ${
              mobileTab === 'list'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>📋</span>
            <span>近い施設リスト</span>
            {filteredLocations.length > 0 && (
              <span className="text-[10px] bg-orange-100 text-orange-600 px-1.5 py-0.5 rounded-full font-black scale-90">
                {filteredLocations.length}
              </span>
            )}
          </button>
        </div>

        {/* COMPACT CATEGORY TAGS SELECTOR (Always visible & wrapped on mobile, preventing hidden icons cut-off) */}
        <div className="bg-orange-50/45 p-1.5 rounded-2xl border border-orange-100/60">
          <div className="text-[9px] font-black text-slate-500 px-1.5 mb-1 flex justify-between items-center">
            <span>🏷️ お助けカテゴリで絞り込む:</span>
            <span className="text-orange-500">お好みの種類を選択</span>
          </div>
          <div className="flex flex-wrap gap-1 max-h-[110px] overflow-y-auto pr-0.5 scrollbar-thin">
            {categoryTabs.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold transition-all border ${
                  selectedCategory === cat.id
                    ? 'bg-orange-500 text-white border-transparent shadow-sm'
                    : 'bg-white text-slate-600 border-slate-200/70 hover:bg-orange-200/40'
                }`}
              >
                <span>{cat.emoji}</span>
                <span>{cat.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* CORE WRAPPER */}
      <div className="flex-grow flex flex-col md:flex-row overflow-hidden relative">
        
        {/* LEFT COLUMN: FILTERS & SPOT LIST */}
        <aside className={`w-full md:w-[390px] shrink-0 bg-amber-50/50 md:border-r-4 border-orange-200 flex flex-col overflow-hidden shadow-md z-10 ${
          mobileTab === 'list' ? 'flex h-full' : 'hidden md:flex'
        }`}>
          
          {/* SEARCH & TOGGLE FILTERS */}
          <div className="p-4 bg-white/80 border-b-2 border-orange-100 space-y-3 shrink-0">
            {/* Search inputs */}
            <div className="relative">
              <input
                type="text"
                placeholder="施設名や地域・キーワードで探す..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleSearchKeyPress}
                className="w-full pl-10 pr-9 py-3 bg-slate-150 bg-slate-100 border-2 border-transparent focus-within:border-orange-300 transition-all rounded-full text-sm font-bold text-slate-800 outline-none placeholder:text-slate-400"
              />
              <span className="absolute left-4 top-3.5 text-slate-400">🔍</span>
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-3.5 p-0.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* GPS 5km Range Filter banner */}
            <div className="flex gap-2 items-center justify-between bg-orange-50 border-2 border-orange-150 p-2.5 rounded-2xl">
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="text-base shrink-0">📍</span>
                <div className="min-w-0">
                  <div className="text-[11px] font-black text-slate-800 leading-tight">
                    現在地から5km圏内絞り込み
                  </div>
                  <div className="text-[9px] text-slate-450 text-slate-500 font-bold truncate leading-normal">
                    {userLocation ? 'GPS範囲5kmサークルが有効' : 'GPSを有効にして絞り込む'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (!userLocation) {
                    tryGeolocate();
                  } else {
                    setFilter5km(!filter5km);
                  }
                }}
                className={`flex items-center justify-center shrink-0 px-2.5 py-1 rounded-xl text-[9px] font-black tracking-tight transition-all cursor-pointer ${
                  filter5km
                    ? 'bg-orange-500 text-white shadow-sm'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-orange-100/50'
                }`}
              >
                {filter5km ? '🟢 5km以内限定' : '⚪ すべて表示'}
              </button>
            </div>

            {/* Quick horizontal categories wrapper - Wrapped to ensure all icons are visible on desktop as well */}
            <div className="flex flex-wrap gap-1 pb-1 select-none max-h-[140px] overflow-y-auto pr-1">
              {categoryTabs.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-black transition-all border-2 ${
                    selectedCategory === cat.id
                      ? 'bg-orange-500 text-white border-transparent shadow-md scale-102'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-orange-50/50'
                  }`}
                >
                  <span>{cat.emoji}</span>
                  <span>{cat.label}</span>
                </button>
              ))}
            </div>

            {/* Structured amenities switches based on the CSV dataset */}
            <div className="bg-amber-50/80 p-3 rounded-2xl border-2 border-amber-100">
              <div className="flex items-center gap-1.5 text-slate-700 text-xs font-black mb-1.5">
                <span className="text-orange-500">✨</span>
                <span>お助け設備で絞り込む</span>
              </div>
              <div className="flex flex-wrap gap-1">
                <button
                  onClick={() => setFilterNursing(!filterNursing)}
                  className={`px-2.5 py-1 rounded-full text-[10px] font-black transition-all border-2 ${
                    filterNursing
                      ? 'bg-sky-500 text-white border-transparent shadow-sm'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-sky-300'
                  }`}
                >
                  🍼 授乳室
                </button>
                <button
                  onClick={() => setFilterDiaper(!filterDiaper)}
                  className={`px-2.5 py-1 rounded-full text-[10px] font-black transition-all border-2 ${
                    filterDiaper
                      ? 'bg-emerald-500 text-white border-transparent shadow-sm'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-300'
                  }`}
                >
                  🚼 おむつ台
                </button>
                <button
                  onClick={() => setFilterHotWater(!filterHotWater)}
                  className={`px-2.5 py-1 rounded-full text-[10px] font-black transition-all border-2 ${
                    filterHotWater
                      ? 'bg-orange-500 text-white border-transparent shadow-sm'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-orange-300'
                  }`}
                >
                  🥛 お湯
                </button>
                <button
                  onClick={() => setFilterStroller(!filterStroller)}
                  className={`px-2.5 py-1 rounded-full text-[10px] font-black transition-all border-2 ${
                    filterStroller
                      ? 'bg-purple-500 text-white border-transparent shadow-sm'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-purple-300'
                  }`}
                >
                  🛒 ベビーカー台
                </button>
                <button
                  onClick={() => setFilterSeating(!filterSeating)}
                  className={`px-2.5 py-1 rounded-full text-[10px] font-black transition-all border-2 ${
                    filterSeating
                      ? 'bg-amber-500 text-white border-transparent shadow-sm'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-amber-300'
                  }`}
                >
                  👶 優先席
                </button>
              </div>
            </div>
          </div>

          {/* FACILITY LIST */}
          <div className="flex-grow overflow-y-auto p-4 space-y-4 select-none bg-amber-50/40">
            <div className="px-2 pb-1 text-xs font-black text-slate-700 flex justify-between items-end">
              <h2 className="text-base font-black">注目のお助けスポット</h2>
              <span className="text-[11px] text-slate-400">({filteredLocations.length}件)</span>
            </div>

            {filteredLocations.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-3xl border-2 border-dashed border-slate-300 space-y-3">
                <HelpCircle className="w-10 h-10 text-orange-400 mx-auto animate-pulse" />
                <p className="text-sm font-black text-slate-800">お探しの設備はありません</p>
                <p className="text-[11px] text-slate-500 leading-normal">
                  キーワードを変えるか、フィルターを外してみてくださいね。
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                    setFilterNursing(false);
                    setFilterDiaper(false);
                    setFilterHotWater(false);
                    setFilterStroller(false);
                    setFilterSeating(false);
                  }}
                  className="mt-2 text-xs font-black text-orange-600 bg-orange-50 hover:bg-orange-100 px-4 py-2 rounded-full border-2 border-orange-200 transition-all cursor-pointer"
                >
                  すべてのフィルターをリセット
                </button>
              </div>
            ) : (
              filteredLocations.map((spot) => {
                const distance = getDistanceString(spot.lat, spot.lng);
                const colorInfo = categoryColors[spot.category] || categoryColors.landmark;
                const isSelected = selectedSpot?.name === spot.name;

                return (
                  <div
                    key={spot.name}
                    id={`spot-item-${spot.name.replace(/\s+/g, '-')}`}
                    onClick={() => handleSpotSelect(spot)}
                    className={`bg-white p-4 rounded-[2rem] border-4 cursor-pointer transition-all duration-300 shadow-lg hover:shadow-xl ${
                      isSelected 
                        ? 'border-orange-500 ring-4 ring-orange-200 bg-orange-50/10' 
                        : 'border-white hover:border-orange-200'
                    }`}
                  >
                    <div className="flex gap-3">
                      <div className={`w-14 h-14 rounded-2xl flex-shrink-0 flex items-center justify-center text-3xl shadow-sm ${
                        spot.category === 'nursing' ? 'bg-sky-100' :
                        spot.category === 'playground' ? 'bg-green-100' :
                        spot.category === 'shopping' ? 'bg-orange-100' : 'bg-amber-100'
                      }`}>
                        {colorInfo.emoji}
                      </div>
                      
                      <div className="flex-1 flex flex-col justify-center min-w-0">
                        <div className="flex flex-wrap items-center gap-1 mb-1">
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${colorInfo.bg} ${colorInfo.text} uppercase`}>
                            {colorInfo.label}
                          </span>
                          {spot.city && (
                            <span className="text-[9px] font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded-full">
                              {spot.city}
                            </span>
                          )}
                          {distance && (
                            <span className="shrink-0 bg-blue-50 text-blue-600 text-[9px] font-black px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                              🛰️ {distance}
                            </span>
                          )}
                        </div>
                        
                        <h3 className="font-black text-slate-900 text-sm leading-tight truncate">
                          {spot.name}
                        </h3>
                        
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                          {spot.amenities}
                        </p>
                      </div>
                    </div>

                    {/* Quick highlight bar inside the card */}
                    <div className="flex flex-wrap gap-1 mt-2.5 text-[9px] font-black">
                      {spot.nursingSpace && <span className="bg-sky-50 text-sky-600 px-2 py-0.5 rounded-full border border-sky-100">💡 授乳室</span>}
                      {spot.diaperChange && <span className="bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded-full border border-emerald-100">👶 おむつ台</span>}
                      {spot.hotWater && <span className="bg-orange-50 text-orange-600 px-2 py-0.5 rounded-full border border-orange-100">🍼 温湯</span>}
                      {spot.strollerFriendly && <span className="bg-purple-50 text-purple-600 px-2 py-0.5 rounded-full border border-purple-100">🛒 カート可</span>}
                    </div>
                  </div>
                );
              })
            )}

            {/* Custom footer report block inside scroll element */}
            <div className="bg-white/50 p-4 rounded-[1.5rem] border-2 border-dashed border-slate-300 flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center text-lg italic font-bold text-slate-400 shrink-0">
                +
              </div>
              <div className="text-xs">
                <span className="font-extrabold text-slate-500 block">欲しいスポットが見つからない？</span>
                <span className="text-slate-400 font-bold">新しいスポットや登録情報を報告する</span>
              </div>
            </div>
          </div>
        </aside>

        {/* MAP CONTAINER (Renders Leaflet Map seamlessly) */}
        <div className={`flex-grow h-full relative ${
          mobileTab === 'map' ? 'block' : 'hidden md:block'
        }`}>
          <div ref={mapContainerRef} className="w-full h-full z-0" />

          {/* FLOATING ACTION OVERLAYS ON THE MAP */}
          <div className="absolute top-4 right-4 flex flex-col gap-2 z-10 pointer-events-auto">
            <button
              onClick={() => {
                if (userLocation && mapRef.current) {
                  mapRef.current.setView([userLocation.lat, userLocation.lng], 14);
                } else {
                  tryGeolocate();
                }
              }}
              className={`p-3.5 rounded-full shadow-2xl transition-all duration-300 transform active:scale-90 flex items-center justify-center border-4 relative cursor-pointer ${
                userLocation 
                  ? 'bg-sky-500 text-white border-white hover:bg-sky-600' 
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-orange-50'
              }`}
              title="現在地に移動 (自動追跡中) 🏃"
            >
              <Compass className={`w-5 h-5 ${isTracking ? 'animate-spin' : ''}`} />
              {userLocation && (
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </span>
              )}
            </button>
          </div>

          {/* FLOATING LEGEND (Collapsible on mobile, always visible on large screens) */}
          <div className="absolute top-4 left-4 z-10 pointer-events-auto">
            {!showLegend ? (
              <button
                type="button"
                onClick={() => setShowLegend(true)}
                className="lg:hidden bg-white/95 backdrop-blur-md px-3 py-2 rounded-2xl border-2 border-orange-300 shadow-lg text-[11px] font-black text-slate-800 hover:bg-orange-50 flex items-center gap-1 cursor-pointer"
              >
                <span>🗺️</span>
                <span>お助けマーク早見表</span>
              </button>
            ) : (
              <div className="bg-white/95 backdrop-blur-md p-4 rounded-[1.5rem] border-4 border-orange-300 shadow-xl max-w-[210px] space-y-2 relative">
                <button
                  type="button"
                  onClick={() => setShowLegend(false)}
                  className="lg:hidden absolute top-2 right-2 w-5 h-5 bg-slate-100 hover:bg-orange-100 rounded-full flex items-center justify-center font-black text-[10px] text-slate-500 cursor-pointer"
                >
                  ✕
                </button>
                <h4 className="text-xs font-black text-slate-900 flex items-center gap-1">
                  <span className="text-orange-500">✨</span>
                  <span>お助けマーク早見表</span>
                </h4>
                <div className="text-[10px] text-slate-700 font-bold leading-normal space-y-1">
                  <div className="flex items-center gap-1"><span>🛝</span> <span>公園・広場 (緑)</span></div>
                  <div className="flex items-center gap-1"><span>🍼</span> <span>授乳室・ケア施設 (青)</span></div>
                  <div className="flex items-center gap-1"><span>🛒</span> <span>お買い物・カート (橙)</span></div>
                  <div className="flex items-center gap-1"><span>🍴</span> <span>飲食店・食事 (黄)</span></div>
                  <div className="flex items-center gap-1"><span>🚗</span> <span>道の駅・おでかけ・他 (紫)</span></div>
                </div>
              </div>
            )}

            {/* Always visible on desktop screens */}
            <div className="hidden lg:block bg-white/95 backdrop-blur-md p-4 rounded-[2rem] border-4 border-orange-300 shadow-xl max-w-xs space-y-2">
              <h4 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                <span className="text-orange-500">✨</span>
                <span>マップ早見表（お助けマーク）</span>
              </h4>
              <div className="text-[11px] text-slate-700 font-bold leading-normal space-y-1">
                <div className="flex items-center gap-1.5"><span>🛝</span> <span>公園・広場・こども館 (緑)</span></div>
                <div className="flex items-center gap-1.5"><span>🍼</span> <span>授乳室・ケア施設 (青)</span></div>
                <div className="flex items-center gap-1.5"><span>🛒</span> <span>お買い物・ベビー用品 (橙)</span></div>
                <div className="flex items-center gap-1.5"><span>🍴</span> <span>飲食店・フードコート (黄)</span></div>
                <div className="flex items-center gap-1.5"><span>🚗</span> <span>道の駅・おでかけ・PA (紫)</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* MOBILE & TABLET BOTTOM SHEET DETAIL PANEL (Vibrant Theme styling) */}
        <div
          id="detail-sheet"
          className={`fixed bottom-0 left-0 right-0 max-h-[85vh] bg-white rounded-t-[3rem] shadow-2xl z-50 transform transition-transform duration-300 overflow-y-auto pointer-events-auto border-t-8 border-orange-500 ${
            selectedSpot ? 'translate-y-0' : 'translate-y-full md:hidden'
          }`}
          style={{ transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)' }}
        >
          {selectedSpot && (
            <div className="p-6 md:p-8 space-y-6 relative">
              {/* Top Drag Visual indicator */}
              <div className="w-16 h-2 bg-slate-200 rounded-full mx-auto -mt-3 mb-4" />

              {/* Close button inside sheet */}
              <button
                onClick={() => setSelectedSpot(null)}
                className="absolute top-6 right-6 w-10 h-10 bg-slate-100 hover:bg-orange-100 text-slate-500 hover:text-orange-600 rounded-full flex items-center justify-center transition-all duration-300 font-black text-md shadow-sm cursor-pointer"
              >
                ✕
              </button>

              {/* Detailed Header elements */}
              <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black border-2 ${
                      categoryColors[selectedSpot.category]?.bg || 'bg-slate-100 border-slate-300 text-slate-800'
                    }`}>
                      <span>{categoryColors[selectedSpot.category]?.emoji || '📍'}</span>
                      <span>{categoryColors[selectedSpot.category]?.label || 'その他'}</span>
                    </span>
                    {selectedSpot.city && (
                      <span className="text-xs font-black text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
                        🏢 {selectedSpot.city}
                      </span>
                    )}
                  </div>
                  <h2 className="text-2xl md:text-4xl font-black text-slate-900 leading-tight">
                    {selectedSpot.name}
                  </h2>
                  {selectedSpot.address && (
                    <p className="text-sm text-slate-500 font-bold flex items-center gap-1">
                      <span className="text-orange-500 text-base">📍</span> {selectedSpot.address}
                    </p>
                  )}
                </div>

                <div className="flex flex-col items-start md:items-end shrink-0 bg-orange-50/55 p-3.5 rounded-2xl border-2 border-orange-100/60 min-w-[200px]">
                  <div className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                    <span className="text-base">🕒</span>
                    <span>{selectedSpot.hours || '営業情報は窓口へ'}</span>
                  </div>
                  <div className="text-green-600 font-black text-xs flex items-center gap-1 mt-1">
                    <span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-ping"></span>
                    <span>おすすめお立ち寄り時間帯</span>
                  </div>
                </div>
              </div>

              {/* Amenities Grid styled as Bento-boxes from Vibrant palette sample */}
              <div className="space-y-3">
                <h4 className="font-black text-slate-900 text-base flex items-center gap-1">
                  <span>🧸</span>
                  <span>お助け設備（バリアフリー・ベビーカー対応）</span>
                </h4>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {/* Nursing support card */}
                  <div className={`p-4 rounded-3xl flex flex-col items-center justify-center text-center gap-2 border-2 transition-all duration-300 ${
                    selectedSpot.nursingSpace 
                      ? 'bg-pink-50 border-pink-100 text-pink-600' 
                      : 'bg-slate-50 border-slate-200/60 text-slate-400 opacity-50'
                  }`}>
                    <span className="text-3xl">🤱</span>
                    <span className="text-xs font-black">個室授乳スペース</span>
                  </div>

                  {/* Diaper custom card */}
                  <div className={`p-4 rounded-3xl flex flex-col items-center justify-center text-center gap-2 border-2 transition-all duration-300 ${
                    selectedSpot.diaperChange 
                      ? 'bg-amber-50 border-amber-100 text-amber-600' 
                      : 'bg-slate-50 border-slate-200/60 text-slate-400 opacity-50'
                  }`}>
                    <span className="text-3xl">🚼</span>
                    <span className="text-xs font-black">おむつ替え台</span>
                  </div>

                  {/* Hot water milk card */}
                  <div className={`p-4 rounded-3xl flex flex-col items-center justify-center text-center gap-2 border-2 transition-all duration-300 ${
                    selectedSpot.hotWater 
                      ? 'bg-sky-50 border-sky-100 text-sky-600' 
                      : 'bg-slate-50 border-slate-200/60 text-slate-400 opacity-50'
                  }`}>
                    <span className="text-3xl">🍼</span>
                    <span className="text-xs font-black">調乳用お湯あり</span>
                  </div>

                  {/* Stroller friendly card */}
                  <div className={`p-4 rounded-3xl flex flex-col items-center justify-center text-center gap-2 border-2 transition-all duration-300 ${
                    selectedSpot.strollerFriendly 
                      ? 'bg-green-50 border-green-100 text-green-600' 
                      : 'bg-slate-50 border-slate-200/60 text-slate-400 opacity-50'
                  }`}>
                    <span className="text-3xl">🛒</span>
                    <span className="text-xs font-black">ベビーカー入店可</span>
                  </div>
                </div>
              </div>

              {/* Core Descriptions */}
              <div className="bg-[#fffbeb] rounded-[2rem] p-6 border-4 border-white shadow-xl">
                <h4 className="font-black text-slate-900 text-lg mb-3 flex items-center gap-1.5">
                  <span>📢</span>
                  <span>施設の詳細・耳よりお助け情報</span>
                </h4>
                <p className="text-slate-700 leading-relaxed text-sm font-bold">
                  {selectedSpot.amenities || '追加情報なし。ベビーカー利用などお気軽にご活用ください。'}
                </p>

                {selectedSpot.phone && (
                  <div className="mt-4 pt-4 border-t border-orange-100 flex items-center gap-2 text-xs">
                    <span className="font-black text-slate-500">📞 お問い合わせ先:</span>
                    <a
                      href={`tel:${selectedSpot.phone}`}
                      className="font-black text-orange-600 underline hover:text-orange-700 active:scale-95 transition-all"
                    >
                      {selectedSpot.phone}
                    </a>
                  </div>
                )}
              </div>

              {/* PAPAMAMA REVIEWS SECTION (Matching detailed star logic from JP script) */}
              <div className="bg-white rounded-[2rem] p-6 border-4 border-orange-200/50 shadow-xl space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="font-black text-slate-900 text-base md:text-lg flex items-center gap-1.5">
                    <span>💬</span>
                    <span>先輩パパママのリアルな口コミ</span>
                    <span className="text-xs bg-orange-100 text-orange-600 px-2.5 py-0.5 rounded-full font-black">
                      {(spotReviews[selectedSpot.name] || []).length}件
                    </span>
                  </h4>
                </div>

                {/* Existing Reviews List */}
                <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
                  {(spotReviews[selectedSpot.name] || []).length === 0 ? (
                    <p className="text-xs text-slate-400 font-bold italic py-2">
                      まだ口コミがありません。最初のおすすめコメントを書いてみませんか？
                    </p>
                  ) : (
                    (spotReviews[selectedSpot.name] || []).map((rev, idx) => (
                      <div key={idx} className="bg-orange-50/20 p-4 rounded-2xl border border-orange-100/40 space-y-1 text-xs">
                        <div className="flex justify-between items-center">
                          <span className="text-amber-500 font-extrabold flex items-center tracking-tight text-xs">
                            {"★".repeat(rev.rating)}{"☆".repeat(5 - rev.rating)}
                            <span className="ml-1 text-slate-700 font-extrabold">{rev.rating}.0</span>
                          </span>
                          <span className="text-[10px] text-slate-400 font-bold">{rev.date}</span>
                        </div>
                        <p className="text-slate-700 leading-normal font-bold">
                          {rev.comment}
                        </p>
                        <div className="text-[10px] text-slate-400 font-black text-right">
                          投稿者: {rev.author}
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Review Submission Form */}
                <form onSubmit={handleAddReview} className="pt-4 border-t border-dashed border-orange-200 space-y-3">
                  <div className="text-xs font-black text-slate-700 flex items-center gap-1">
                    <span>✍️</span>
                    <span>このスポットの体験談を投稿する</span>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3">
                    {/* Name Input */}
                    <div className="flex-1">
                      <input
                        type="text"
                        placeholder="ニックネーム (例: 浪岡ママ)"
                        value={authorInput}
                        onChange={(e) => setAuthorInput(e.target.value)}
                        maxLength={15}
                        className="w-full px-4 py-2 bg-slate-50 border-2 border-slate-200 focus:border-orange-400 focus:bg-white rounded-xl text-xs font-bold outline-none transition-all"
                      />
                    </div>

                    {/* Rating Picker */}
                    <div className="flex items-center gap-1.5 bg-slate-50 px-3.5 py-2 border-2 border-slate-200 rounded-xl select-none">
                      <span className="text-[10px] font-black text-slate-500">お助け度:</span>
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((num) => (
                          <button
                            type="button"
                            key={num}
                            onClick={() => setRatingInput(num)}
                            className="text-xs transition-transform active:scale-125 focus:outline-none cursor-pointer"
                          >
                            <span className={num <= ratingInput ? "text-amber-500 text-sm" : "text-slate-300 text-sm"}>
                              ★
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Comment field and submit button */}
                  <div className="flex gap-2 items-end">
                    <div className="flex-1">
                      <textarea
                        rows={1}
                        placeholder="「授乳室が個室で快適」「オムツ用のゴミ箱がある」など教えてください"
                        value={commentInput}
                        onChange={(e) => setCommentInput(e.target.value)}
                        maxLength={120}
                        required
                        className="w-full px-4 py-2.5 bg-slate-50 border-2 border-slate-200 focus:border-orange-400 focus:bg-white rounded-xl text-xs font-bold outline-none resize-none transition-all"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-5 py-2.5 h-[38px] bg-orange-500 hover:bg-orange-600 active:scale-95 text-white text-xs font-black rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center shrink-0"
                    >
                      口コミ投稿
                    </button>
                  </div>
                </form>
              </div>

              {/* Distances and other variables if GPS coordinates calculated */}
              <div className="flex flex-col sm:flex-row gap-4">
                {getDistanceString(selectedSpot.lat, selectedSpot.lng) && (
                  <div className="flex-1 bg-sky-50 border-2 border-sky-100 p-4 rounded-2xl flex items-center gap-3 text-sky-800">
                    <Compass className="w-6 h-6 text-sky-500 animate-spin-slow shrink-0" />
                    <div>
                      <span className="text-[10px] uppercase font-black tracking-widest block text-sky-500">GPS実地距離</span>
                      <span className="font-black text-sm">現在地から約 {getDistanceString(selectedSpot.lat, selectedSpot.lng)}</span>
                    </div>
                  </div>
                )}
                {selectedSpot.holidays && (
                  <div className="flex-1 bg-slate-50 border-2 border-slate-200 p-4 rounded-2xl flex items-center gap-3 text-slate-700">
                    <Calendar className="w-6 h-6 text-slate-400 shrink-0" />
                    <div>
                      <span className="text-[10px] uppercase font-black tracking-widest block text-slate-400">休館・休業予定</span>
                      <span className="font-black text-sm">{selectedSpot.holidays}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom guide action button styled beautifully from the sample */}
              <div className="pt-4 flex justify-end">
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${selectedSpot.lat},${selectedSpot.lng}`}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  rel="noopener noreferrer"
                  className="bg-slate-900 text-white px-10 py-4 rounded-full font-black text-base shadow-xl active:scale-95 hover:bg-slate-800 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <ExternalLink className="w-5 h-5" />
                  <span>Googleマップでルート案内を開く</span>
                </a>
              </div>
            </div>
          )}
        </div>

      </div>

      {/* PERSISTENT HIGH-FIDELITY BOTTOM FOOTER */}
      <footer className="bg-white px-8 py-4 border-t-2 border-orange-100 shrink-0 flex flex-col gap-3 text-xs select-none z-20 shadow-inner">
        <div className="flex flex-col gap-2 font-black text-slate-400">
          <div className="flex flex-wrap gap-x-3 gap-y-1 items-center">
            <span className="text-orange-500 font-extrabold pr-1 shrink-0">青森県:</span>
            <span>八戸市</span>
            <span>青森市</span>
            <span>弘前市</span>
            <span>十和田市</span>
            <span>三沢市</span>
            <span>むつ市</span>
            <span>南部町</span>
            <span>三戸町</span>
            <span>階上町</span>
            <span>田子町</span>
            <span>おいらせ町</span>
            <span>六戸町</span>
            <span>七戸町</span>
            <span>東北町</span>
            <span>野辺地町</span>
            <span>横浜町</span>
            <span>六ケ所村</span>
            <span>大間町</span>
            <span>東通村</span>
            <span>風間浦村</span>
            <span>佐井村</span>
          </div>
          <div className="flex flex-wrap gap-x-3 gap-y-1 items-center">
            <span className="text-sky-500 font-extrabold pr-1 shrink-0">岩手県:</span>
            <span>盛岡市</span>
            <span>二戸市</span>
            <span>久慈市</span>
            <span>八幡平市</span>
            <span>滝沢市</span>
            <span>洋野町</span>
            <span>軽米町</span>
            <span>一戸町</span>
            <span>九戸村</span>
            <span>葛巻町</span>
            <span>野田村</span>
            <span>普代村</span>
            <span>山田町</span>
            <span>田野畑村</span>
            <span>岩手町</span>
            <span>岩泉町</span>
            <span>雫石町</span>
            <span>平泉町</span>
            <span>陸前高田市</span>
            <span>遠野市</span>
            <span>釜石市</span>
            <span>紫波町</span>
          </div>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center gap-2 border-t border-slate-150 pt-2 shrink-0 font-bold text-slate-800">
          <div className="text-slate-500 text-[10px] md:text-xs">
            ※ 上記の対象エリア内のベビーカー対応店、授乳室、おむつ替え施設等を掲載しています。
          </div>
          <div className="text-xs md:text-sm">
            現在 青森・岩手に <span className="text-orange-500 underline font-black">{locations.length}</span> の安心お立ち寄りスポットが掲載中 🎒
          </div>
        </div>
      </footer>
    </div>
  );
}
